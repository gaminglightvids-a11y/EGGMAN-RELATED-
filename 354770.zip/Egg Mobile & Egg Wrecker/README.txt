Egg Mobile / Wrecker from Sonic the Hedgehog 4: Episode 1 ripped by DogToon64.

If used, give credit to SEGA, Sonic Team, and Dimps.

Credit to DogToon64 is optional, but would be nice.